version("1.0.0")
author("Cfx.re <root@cfx.re>")
description("Builds resources with yarn. To learn more: https://classic.yarnpkg.com")
repository("https://github.com/Z3rio/fivem-builders")

fx_version("cerulean")
game("common")

server_script("yarn_builder.js")
